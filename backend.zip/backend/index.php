<?php
header('Access-Control-Allow-Origin: http://pnyx-surveys.com');
header('Content-Type: application/json');
header('Access-Control-Allow-Credentials: true');

include 'connection.php';

echo 'Heeeeheeee';
?>
