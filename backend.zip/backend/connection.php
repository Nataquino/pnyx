<?php
$servername = "localhost"; // Change to your database server name
$username = "pnyxsurv_admin"; // Change to your database username
$password = "iHhL_]ClIy{0"; // Change to your database password
$dbname = "pnyxsurv_pnyxDB"; // Change to your database name

$conn = new mysqli("$servername", $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
